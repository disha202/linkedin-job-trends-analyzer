# Initial Insights
- Top skills in demand: Java, Python, React
- Cities with max jobs: Bangalore, Pune, Hyderabad
